package com.benjamin.nearly; // CHANGE to your app's package

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;

/**
 * Instant delivery without Firebase Cloud Messaging: keeps one lightweight streaming connection
 * (Firebase Realtime Database server-sent events) open while the phone has internet. New messages,
 * hearts and calls from your partner arrive within a second or two, even with the app closed.
 * Shows a small silent "Nearly is connected" notification (Android requires it).
 * Switch it on/off with NearlyWidgets.setLive(true|false).
 */
public class NearlyLiveService extends Service {
    static final String CH_LIVE = "nearly_live", CH_CALL = "nearly_call";
    static volatile boolean visible = false;          // app on screen -> no duplicate notifications
    private static final HashSet<String> WATCH = new HashSet<>(Arrays.asList(
            "notes", "call", "photoIndex", "notify", "game", "events", "tasks", "candle"));

    private volatile boolean running = false;
    private volatile HttpURLConnection conn;
    private long lastPull = 0;

    static void start(Context c) {
        try {
            Intent i = new Intent(c, NearlyLiveService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Throwable ignored) { }
    }

    static void stop(Context c) {
        try { c.stopService(new Intent(c, NearlyLiveService.class)); } catch (Throwable ignored) { }
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        startFg();                                     // must happen promptly after startForegroundService
        if (!NearlyStore.sp(this).getBoolean("live", false) || !NearlyStore.paired(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            running = true;
            new Thread(new Runnable() { public void run() { loop(); } }).start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try { if (conn != null) conn.disconnect(); } catch (Throwable ignored) { }
        super.onDestroy();
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(CH_LIVE, "Instant messages", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_LIVE) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_nearly_heart).setContentTitle("Nearly is connected").setContentText("Messages and calls arrive instantly").setOngoing(true);
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (open != null) b.setContentIntent(PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(7390, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(7390, n);
    }

    private void loop() {
        int fail = 0;
        while (running) {
            if (!NearlyStore.paired(this) || !NearlyStore.sp(this).getBoolean("live", false)) break;
            try {
                stream();
                fail = 0;
            } catch (Throwable t) {
                fail++;
            }
            try { Thread.sleep(Math.min(60000L, 2000L * (1 + (long) fail * fail))); } catch (InterruptedException e) { break; }
        }
        running = false;
        stopSelf();
    }

    /** Blocks while the stream is open; returns/throws when it drops (the loop reconnects). */
    private void stream() throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(NearlySync.base(this) + ".json").openConnection();
        conn = h;
        try {
            h.setRequestProperty("Accept", "text/event-stream");
            h.setConnectTimeout(10000);
            h.setReadTimeout(90000);                   // Firebase sends a keep-alive about every 30 s
            if (h.getResponseCode() >= 300) throw new Exception("http");
            BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"));
            String line, ev = "";
            while (running && (line = r.readLine()) != null) {
                if (line.startsWith("event:")) ev = line.substring(6).trim();
                else if (line.startsWith("data:")) handle(ev, line.substring(5).trim());
            }
        } finally {
            h.disconnect();
        }
    }

    private void handle(String ev, String data) {
        if (!ev.equals("put") && !ev.equals("patch")) return;
        String path;
        try { path = new JSONObject(data).optString("path", "/"); } catch (Exception e) { return; }
        String seg = path.length() > 1 ? path.substring(1).split("/")[0] : "";
        if (!seg.isEmpty() && !WATCH.contains(seg)) return;       // ignore typing, read receipts, presence
        long wait = 1500 - (System.currentTimeMillis() - lastPull);
        if (wait > 0) { try { Thread.sleep(wait); } catch (InterruptedException ignored) { } }
        lastPull = System.currentTimeMillis();
        NearlySync.pullLite(this, !visible);
        checkCall();
    }

    private void checkCall() {
        try {
            if (visible) return;
            NearlyData d = new NearlyData(this);
            JSONObject c = d.o("call");
            if (!"ringing".equals(c.optString("state")) || !c.optString("from").equals(d.pslot)) return;
            long id = c.optLong("id", 0);
            if (id == 0 || System.currentTimeMillis() - c.optLong("ts", 0) > 45000) return;
            if (NearlyStore.sp(this).getLong("lastCallNotified", 0) == id) return;
            NearlyStore.sp(this).edit().putLong("lastCallNotified", id).apply();
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH_CALL, "Calls", NotificationManager.IMPORTANCE_HIGH));
            Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH_CALL) : new Notification.Builder(this);
            b.setSmallIcon(R.drawable.ic_nearly_heart).setContentTitle("📞 " + d.pName() + " is calling")
                    .setContentText("Tap to answer in Nearly").setCategory(Notification.CATEGORY_CALL).setAutoCancel(true);
            if (Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(45000);
            if (open != null) b.setContentIntent(PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            nm.notify(7399, b.build());
        } catch (Throwable ignored) { }
    }
}
